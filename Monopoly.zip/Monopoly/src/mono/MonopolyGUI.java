package mono;

import javax.swing.JFrame;

public class MonopolyGUI extends JFrame {
	public MonopolyGUI() {
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
