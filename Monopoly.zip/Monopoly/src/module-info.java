/**
 * 
 */
/**
 * @author keega
 *
 */
module Monopoly {
	requires java.desktop;
}